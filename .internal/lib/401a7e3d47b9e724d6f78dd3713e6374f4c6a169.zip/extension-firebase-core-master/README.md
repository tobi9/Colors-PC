# extension-firebase-core

This is a base extension that can be a dependency for other extensions.

This extension was made with [pompom](https://github.com/britzl/pompom) script. If you want to create your own version of this extension using pompom please pay attention to the manual section in AndroidManifest.xml file. 