package com.defold.iap;

public interface IListProductsListener {
	public void onProductsResult(int resultCode, String productList);
}
