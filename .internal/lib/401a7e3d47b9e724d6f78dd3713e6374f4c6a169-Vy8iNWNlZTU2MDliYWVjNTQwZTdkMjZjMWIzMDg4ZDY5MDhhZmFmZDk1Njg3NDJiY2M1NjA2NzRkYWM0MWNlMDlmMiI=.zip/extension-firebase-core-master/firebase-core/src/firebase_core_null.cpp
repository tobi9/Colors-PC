extern "C" void FirebaseCoreExt()
{

}