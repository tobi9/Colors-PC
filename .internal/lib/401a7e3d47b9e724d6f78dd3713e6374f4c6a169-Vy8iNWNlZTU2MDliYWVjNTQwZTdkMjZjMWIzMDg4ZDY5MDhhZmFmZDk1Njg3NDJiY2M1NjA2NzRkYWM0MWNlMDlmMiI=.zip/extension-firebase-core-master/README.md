# extension-firebase-core (DEPRECATED)

Use Android base extension firebase-core-x.y.z.zip instead:

https://github.com/defold/android-base-extensions/releases
